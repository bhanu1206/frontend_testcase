import {
  Button,
  FormControl,
  FormControlLabel,
  ListItemButton,
  ListItemText,
  Radio,
  RadioGroup,
  TextField,
} from "@mui/material";
import { useState } from "react";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import StepContent from "@mui/material/StepContent";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import PropTypes from "prop-types";
import { styled } from "@mui/material/styles";
import GitHubIcon from "@mui/icons-material/GitHub";
import GroupWorkOutlinedIcon from "@mui/icons-material/GroupWorkOutlined";
import PlayCircleOutlineIcon from "@mui/icons-material/PlayCircleOutline";
import MoveToInboxOutlinedIcon from "@mui/icons-material/MoveToInboxOutlined";
import {
  chooseBranch,
  generateTestCases,
  verifyRepository,
} from "../services/test-service";
import JSZip from "jszip";
import DownloadIcon from "@mui/icons-material/Download";
import TextSnippetIcon from "@mui/icons-material/TextSnippet";

const steps = [
  {
    label: "Verify Repository",
  },
  {
    label: "Select Branch",
  },
  {
    label: "Generate Test Cases",
  },
  {
    label: "Deploy Project",
  },
];

export function Home(props) {
  const [repoUrl, setRepoUrl] = useState("");
  const [urlStatus, setUrlStatus] = useState("");
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState("");
  const [applicationName, setApplicationName] = useState("app");

  const [activeStep, setActiveStep] = useState(0);

  const [base64String, setBase64String] = useState("");
  const [fileList, setFileList] = useState([]);
  const [selectedFileContent, setSelectedFileContent] = useState(null);
  const [selectedFileName, setSelectedFileName] = useState("");

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  const verifyRepo = () => {
    verifyRepository(repoUrl).then(
      (resp) => {
        setUrlStatus("verified");
        setBranches(resp.data.branches);
      },
      (error) => {
        setUrlStatus("invalid");
        console.log(error);
      }
    );
  };

  const handleBranchChange = (evt) => {
    setSelectedBranch(evt.target.value);

    chooseBranch(repoUrl, evt.target.value).then(
      (resp) => {
        console.log(resp.data);
        setApplicationName(resp.data.applicationName);
      },
      (error) => {
        console.log(error);
      }
    );
  };

  const generateTestCasesFun = () => {
    generateTestCases(applicationName).then(
      (resp) => {
        try {
          setBase64String(resp.data);
          const zip = new JSZip();
          zip.loadAsync(resp.data, { base64: true }).then((zip) => {
            const files = Object.keys(zip.files);
            setFileList(files);
          });
        } catch (err) {
          console.error("Error loading ZIP file:", err);
        }
      },
      (error) => {
        console.log(error);
      }
    );
  };

  const handleFileClick = async (fileName) => {
    try {
      const zip = new JSZip();
      const file = await zip.loadAsync(base64String, { base64: true });
      const content = await file.file(fileName).async("string");
      setSelectedFileContent(content);
      setSelectedFileName(fileName);
    } catch (err) {
      console.error("Error reading file:", err);
      setSelectedFileContent(null);
    }
  };

  return (
    <div className="container-fluid">
      <Box sx={{ m: 5 }}>
        <Stepper activeStep={activeStep} orientation="vertical">
          {steps.map((step, index) => (
            <Step key={step.label}>
              <StepLabel StepIconComponent={ColorlibStepIcon}>
                {step.label}
              </StepLabel>
              <StepContent>
                {index === 0 && (
                  <div className=" my-5">
                    <TextField
                      fullWidth
                      className="rounded"
                      id="fullWidth"
                      placeholder="Git Repository URL"
                      onChange={(evt) => setRepoUrl(evt.target.value)}
                      value={repoUrl}
                      InputProps={{
                        endAdornment: (
                          <Button
                            disabled={!repoUrl}
                            className="pointer repoInputBtn"
                            onClick={
                              urlStatus === "verified" ? handleNext : verifyRepo
                            }
                          >
                            {urlStatus === "verified" ? "Next" : "Verify"}
                          </Button>
                        ),
                      }}
                    />
                    {urlStatus === "verified" && (
                      <li className="text-muted mt-2 mx-1">
                        Repository verified successfully.
                      </li>
                    )}
                    {urlStatus === "invalid" && (
                      <li className="text-danger mt-2 mx-1">
                        Please provide valid URL
                      </li>
                    )}
                  </div>
                )}

                {index === 1 && (
                  <FormControl>
                    <RadioGroup
                      aria-labelledby="demo-controlled-radio-buttons-group"
                      name="controlled-radio-buttons-group"
                      onChange={handleBranchChange}
                    >
                      {branches.map((value) => {
                        return (
                          <FormControlLabel
                            key={value}
                            value={value}
                            control={<Radio />}
                            label={value}
                          />
                        );
                      })}
                    </RadioGroup>
                  </FormControl>
                )}

                {index === 2 && (
                  <div>
                    <table className="table table-md table-light table-borderless my-3">
                      <thead className="border-bottom">
                        <tr>
                          <th scope="col">Application Name</th>
                          <th scope="col">App Technology</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>{applicationName}</td>
                          <td>Java</td>
                          <td>
                            <Button onClick={generateTestCasesFun}>
                              Generate Tests
                            </Button>
                          </td>
                        </tr>
                      </tbody>
                    </table>

                    {fileList.length > 0 && (
                      <div className="my-3 row ">
                        <h5 className="text-dark ">Generated test files :</h5>
                        <div className="col-3 py-2 border rounded">
                          {fileList.map((file, index) => (
                            <ListItemButton
                              selected={selectedFileName === file}
                              onClick={() => handleFileClick(file)}
                              component="a"
                              key={index}
                              href="#simple-list"
                            >
                              <TextSnippetIcon /> &nbsp; &nbsp;
                              <ListItemText primary={file} />
                            </ListItemButton>
                          ))}

                          {/* <Button className="mt-5 text-dark border-bottom">
                            <DownloadIcon /> &nbsp; Download Test Cases
                          </Button> */}
                        </div>

                        <div className="col-9 p-2 border rounded">
                          <h5 className="text-dark">{selectedFileName} :</h5>

                          <pre className="mt-4">{selectedFileContent}</pre>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {index > 0 ? (
                  <Box sx={{ mt: 1 }}>
                    <div>
                      <Button
                        variant="contained"
                        // color="secondary"
                        className="bg-dark"
                        onClick={handleNext}
                        sx={{ mt: 1, mr: 1 }}
                      >
                        {index === steps.length - 1 ? "Finish" : "Next"}
                      </Button>
                      <Button
                        disabled={index === 0}
                        className="text-danger"
                        onClick={handleBack}
                        sx={{ mt: 1, mr: 1 }}
                      >
                        Back
                      </Button>
                    </div>
                  </Box>
                ) : (
                  ""
                )}
              </StepContent>
            </Step>
          ))}
        </Stepper>
        {activeStep === steps.length && (
          <Paper square elevation={0} sx={{ p: 3 }}>
            <Typography>All steps completed - you&apos;re finished</Typography>
            <Button onClick={handleReset} sx={{ mt: 1, mr: 1 }}>
              Reset
            </Button>
          </Paper>
        )}
      </Box>
    </div>
  );
}

const ColorlibStepIconRoot = styled("div")(({ theme, ownerState }) => ({
  backgroundColor:
    theme.palette.mode === "dark" ? theme.palette.grey[700] : "#ccc",
  zIndex: 1,
  color: "#fff",
  width: 35,
  height: 35,
  display: "flex",
  borderRadius: "50%",
  justifyContent: "center",
  alignItems: "center",
  ...(ownerState.active && {
    backgroundImage:
      "linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)",
    boxShadow: "0 4px 10px 0 rgba(0,0,0,.25)",
  }),
  ...(ownerState.completed && {
    backgroundImage:
      "linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)",
  }),
}));

function ColorlibStepIcon(props) {
  const { active, completed, className } = props;

  const icons = {
    1: <GitHubIcon />,
    2: <GroupWorkOutlinedIcon />,
    3: <PlayCircleOutlineIcon />,
    4: <MoveToInboxOutlinedIcon />,
  };

  return (
    <ColorlibStepIconRoot
      ownerState={{ completed, active }}
      className={className}
    >
      {icons[String(props.icon)]}
    </ColorlibStepIconRoot>
  );
}

ColorlibStepIcon.propTypes = {
  /**
   * Whether this step is active.
   * @default false
   */
  active: PropTypes.bool,
  className: PropTypes.string,
  /**
   * Mark the step as completed. Is passed to child components.
   * @default false
   */
  completed: PropTypes.bool,
  /**
   * The label displayed in the step icon.
   */
  icon: PropTypes.node,
};
// import * as React from "react";
// import { useState } from "react";
// import { styled } from "@mui/material/styles";
// import Accordion from "@mui/material/Accordion";
// import AccordionSummary from "@mui/material/AccordionSummary";
// import AccordionDetails from "@mui/material/AccordionDetails";
// import Typography from "@mui/material/Typography";
// import TextField from "@mui/material/TextField";
// import Button from "@mui/material/Button";
// import FormControlLabel from "@mui/material/FormControlLabel";
// import Radio from "@mui/material/Radio";
// import RadioGroup from "@mui/material/RadioGroup";
// import GitHubIcon from "@mui/icons-material/GitHub";
// import GroupWorkOutlinedIcon from "@mui/icons-material/GroupWorkOutlined";
// import PlayCircleOutlineIcon from "@mui/icons-material/PlayCircleOutline";
// import MoveToInboxOutlinedIcon from "@mui/icons-material/MoveToInboxOutlined";
// import { Container, ListItemButton, ListItemText, Box } from "@mui/material";
 
// import {
//   verifyRepository,
//   chooseBranch,
//   generateTestCases,
// } from "../services/test-service";
// import JSZip from "jszip";
// import DownloadIcon from "@mui/icons-material/Download";
// import TextSnippetIcon from "@mui/icons-material/TextSnippet";
// import {
//   MdKeyboardDoubleArrowDown,
//   MdKeyboardDoubleArrowUp,
// } from "react-icons/md";
 
// export function Home() {
//   const [expanded, setExpanded] = useState("panel1");
//   const [repoUrl, setRepoUrl] = useState("");
//   const [urlStatus, setUrlStatus] = useState("");
//   const [branches, setBranches] = useState([]);
//   const [selectedBranch, setSelectedBranch] = useState("");
//   const [applicationName, setApplicationName] = useState("app");
//   const [activeStep, setActiveStep] = useState(0);
//   const [base64String, setBase64String] = useState("");
//   const [fileList, setFileList] = useState([]);
//   const [selectedFileContent, setSelectedFileContent] = useState(null);
//   const [selectedFileName, setSelectedFileName] = useState("");
 
//   const handleChange = (panel) => (event, newExpanded) => {
//     setExpanded(newExpanded ? panel : false);
//   };
 
//   const handleNext = () => {
//     setExpanded(`panel${parseInt(expanded.slice(5)) + 1}`);
//   };
 
//   const handleBack = () => {
//     setExpanded(`panel${parseInt(expanded.slice(5)) - 1}`);
//   };
 
//   const verifyRepo = () => {
//     verifyRepository(repoUrl).then(
//       (resp) => {
//         setUrlStatus("verified");
//         setBranches(resp.data.branches);
//       },
//       (error) => {
//         setUrlStatus("invalid");
//         console.log(error);
//       }
//     );
//   };
 
//   const handleBranchChange = (evt) => {
//     setSelectedBranch(evt.target.value);
 
//     chooseBranch(repoUrl, evt.target.value).then(
//       (resp) => {
//         console.log(resp.data);
//         setApplicationName(resp.data.applicationName);
//       },
//       (error) => {
//         console.log(error);
//       }
//     );
//   };
 
//   const deployProject = () => {
//     // Your deployment logic goes here
//     console.log("Deploying project...");
//   };
 
//   const generateTestCasesFun = () => {
//     generateTestCases(applicationName).then(
//       (resp) => {
//         try {
//           setBase64String(resp.data);
//           const zip = new JSZip();
//           zip.loadAsync(resp.data, { base64: true }).then((zip) => {
//             const files = Object.keys(zip.files);
//             setFileList(files);
//           });
//         } catch (err) {
//           console.error("Error loading ZIP file:", err);
//         }
//       },
//       (error) => {
//         console.log(error);
//       }
//     );
//   };
 
//   const handleFileClick = async (fileName) => {
//     try {
//       const zip = new JSZip();
//       const file = await zip.loadAsync(base64String, { base64: true });
//       const content = await file.file(fileName).async("string");
//       setSelectedFileContent(content);
//       setSelectedFileName(fileName);
//     } catch (err) {
//       console.error("Error reading file:", err);
//       setSelectedFileContent(null);
//     }
//   };
 
//   return (
//     <div style={{ marginTop: "50px" }}>
//       <Container maxWidth="lg">
//         <Accordion
//           expanded={expanded === "panel1"}
//           onChange={handleChange("panel1")}
//         >
//           <AccordionSummary
//             expandIcon={
//               expanded === "panel1" ? (
//                 <MdKeyboardDoubleArrowUp />
//               ) : (
//                 <MdKeyboardDoubleArrowDown />
//               )
//             }
//             aria-controls="panel1d-content"
//             id="panel1d-header"
//             sx={{ justifyContent: "flex-start", height: "80px" }}
//           >
//             <Box
//               sx={{
//                 marginRight: 1,
//                 backgroundColor: "#007FFF",
//                 borderRadius: "50%",
//                 padding: "1px 6px 6px 6px",
//               }}
//             >
//               <GitHubIcon style={{ color: "white", fontSize: "20px" }} />
//             </Box>
//             <Typography sx={{ fontSize: '0.875rem' }}>Verify Repository</Typography>
//           </AccordionSummary>
//           <AccordionDetails>
//             <TextField
//               fullWidth
//               className="rounded"
//               id="fullWidth"
//               placeholder="Git Repository URL"
//               onChange={(evt) => setRepoUrl(evt.target.value)}
//               value={repoUrl}
//               sx={{ width: "60%", mb: 8, height: "0.4375em" }}
//               InputProps={{
//                 endAdornment: (
//                   <Button
//                     disabled={!repoUrl}
//                     className="pointer repoInputBtn"
//                     onClick={urlStatus === "verified" ? handleNext : verifyRepo}
//                   >
//                     {urlStatus === "verified" ? "Next" : "Verify"}
//                   </Button>
//                 ),
//               }}
//             />
//             {urlStatus === "verified" && (
//               <li className="text-muted mt-2 mx-1">
//                 Repository verified successfully.
//               </li>
//             )}
//             {urlStatus === "invalid" && (
//               <li className="text-danger mt-2 mx-1">
//                 Please provide valid URL
//               </li>
//             )}
//           </AccordionDetails>
//         </Accordion>
 
//         <Accordion
//           expanded={expanded === "panel2"}
//           onChange={handleChange("panel2")}
//         >
//           <AccordionSummary
//             expandIcon={
//               expanded === "panel2" ? (
//                 <MdKeyboardDoubleArrowUp />
//               ) : (
//                 <MdKeyboardDoubleArrowDown />
//               )
//             }
//             aria-controls="panel2d-content"
//             id="panel2d-header"
//             sx={{ justifyContent: "flex-start", height: "80px" }}
//           >
//             <Box
//               sx={{
//                 marginRight: 1,
//                 backgroundColor: "#007FFF",
//                 borderRadius: "50%",
//                 padding: "1px 6px 6px 6px",
//               }}
//             >
//               <GroupWorkOutlinedIcon
//                 style={{ color: "white", fontSize: "20px" }}
//               />
//             </Box>
//             <Typography sx={{ fontSize: '0.875rem' }}>Select Branch</Typography>
//           </AccordionSummary>
//           <AccordionDetails>
//             {expanded === "panel2" && (
//               <>
//                 <RadioGroup
//                   aria-labelledby="demo-controlled-radio-buttons-group"
//                   name="controlled-radio-buttons-group"
//                   onChange={handleBranchChange}
//                 >
//                   {branches.map((value) => {
//                     return (
//                       <FormControlLabel
//                         key={value}
//                         value={value}
//                         control={<Radio />}
//                         label={value}
//                       />
//                     );
//                   })}
//                 </RadioGroup>
 
//                 <Box sx={{ mt: 1 }}>
//                   <div>
//                     <Button
//                       variant="contained"
//                       className="bg-dark"
//                       onClick={handleNext}
//                       sx={{ mt: 1, mr: 1 }}
//                     >
//                       Next
//                     </Button>
//                     <Button
//                       disabled={expanded !== "panel2"}
//                       className="text-danger"
//                       onClick={handleBack}
//                       sx={{ mt: 1, mr: 1 }}
//                     >
//                       Back
//                     </Button>
//                   </div>
//                 </Box>
//               </>
//             )}
//           </AccordionDetails>
//         </Accordion>
 
//         <Accordion
//           expanded={expanded === "panel3"}
//           onChange={handleChange("panel3")}
//         >
//           <AccordionSummary
//             expandIcon={
//               expanded === "panel3" ? (
//                 <MdKeyboardDoubleArrowUp />
//               ) : (
//                 <MdKeyboardDoubleArrowDown />
//               )
//             }
//             aria-controls="panel3d-content"
//             id="panel3d-header"
//             sx={{ justifyContent: "flex-start", height: "80px" }}
//           >
//             <Box
//               sx={{
//                 marginRight: 1,
//                 backgroundColor: "#007FFF",
//                 borderRadius: "50%",
//                 padding: "1px 6px 6px 6px",
//               }}
//             >
//               <PlayCircleOutlineIcon
//                 style={{ color: "white", fontSize: "20px" }}
//               />
//             </Box>
//             <Typography sx={{ fontSize: '0.875rem' }}>Generate Test Cases</Typography>
//           </AccordionSummary>
//           <AccordionDetails>
//             {expanded === "panel3" && (
//               <>
//                 <table className="table table-md table-light table-borderless my-3">
//                   <thead className="border-bottom">
//                     <tr>
//                       <th scope="col">Application Name</th>
//                       <th scope="col">App Technology</th>
//                       <th scope="col">Action</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     <tr>
//                       <td>{applicationName}</td>
//                       <td>Java</td>
//                       <td>
//                         <Button onClick={generateTestCasesFun}>
//                           Generate Tests
//                         </Button>
//                       </td>
//                     </tr>
//                   </tbody>
//                 </table>
 
//                 {fileList.length > 0 && (
//                   <div className="my-3 row ">
//                     <h5 className="text-dark ">Generated test files :</h5>
//                     <div className="col-3 py-2 border rounded">
//                       {fileList.map((file, index) => (
//                         <ListItemButton
//                           selected={selectedFileName === file}
//                           onClick={() => handleFileClick(file)}
//                           component="a"
//                           key={index}
//                           href="#simple-list"
//                         >
//                           <TextSnippetIcon /> &nbsp; &nbsp;
//                           <ListItemText primary={file} />
//                         </ListItemButton>
//                       ))}
//                     </div>
 
//                     <div className="col-9 p-2 border rounded">
//                       <h5 className="text-dark">{selectedFileName} :</h5>
 
//                       <pre className="mt-4">{selectedFileContent}</pre>
//                     </div>
//                   </div>
//                 )}
//               </>
//             )}
//           </AccordionDetails>
//         </Accordion>
//         <Accordion
//           expanded={expanded === "panel4"}
//           onChange={handleChange("panel4")}
//         >
//           <AccordionSummary
//             expandIcon={
//               expanded === "panel4" ? (
//                 <MdKeyboardDoubleArrowUp />
//               ) : (
//                 <MdKeyboardDoubleArrowDown />
//               )
//             }
//             aria-controls="panel4d-content"
//             id="panel4d-header"
//             sx={{ justifyContent: "flex-start", height: "80px" }}
//           >
//             <Box
//               sx={{
//                 marginRight: 1,
//                 backgroundColor: "#007FFF",
//                 borderRadius: "50%",
//                 padding: "1px 6px 6px 6px",
//               }}
//             >
//               <MoveToInboxOutlinedIcon
//                 style={{ color: "white", fontSize: "20px" }}
//               />
//             </Box>
//             <Typography sx={{ fontSize: '0.875rem' }}>Deploy Project</Typography>
//           </AccordionSummary>
//           {/* <AccordionDetails>
//             <Typography>This is where you can deploy your project.</Typography>
//             <Button onClick={deployProject}>Deploy</Button>
//           </AccordionDetails> */}
//         </Accordion>
//       </Container>
//     </div>
//   );
// }