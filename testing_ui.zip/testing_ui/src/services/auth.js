import axiosConfig from "../config/axiosConfig"

export const verifyAuth = async(credentials)=>{
    return await axiosConfig.post('auth/login',credentials)
}

export const registerUser = async(userData) =>{
    return await axiosConfig.post('auth/register',userData)
}

export const userForgotPasswordMail = async(userData) =>{
    return await axiosConfig.post('auth/forgotPassword',userData)
}

export const resetPassword = async(userData) =>{
    return await axiosConfig.post('auth/resetPassword',userData)
}