import LockIcon from "@mui/icons-material/Lock";
import MailIcon from "@mui/icons-material/Mail";
import PersonIcon from "@mui/icons-material/Person";
import Card from "@mui/joy/Card";
import CardContent from "@mui/joy/CardContent";
import CardCover from "@mui/joy/CardCover";
import Grid from "@mui/joy/Grid";
import MuiAlert from "@mui/material/Alert";
import Avatar from "@mui/material/Avatar";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Snackbar from "@mui/material/Snackbar";
import * as React from "react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { verifyAuth } from "../services/auth";
import "../styles/login.css";
import { userForgotPasswordMail } from "../services/auth";

export default function Login(props) {
  const navigate = useNavigate();

  const [values, setValues] = useState({
    username: "",
    password: "",
  });
  const [forgotPasswordMail, setForgotPasswordMail] = useState("");
  const [open, setOpen] = useState(false);
  const [severity, setSeverity] = useState("");
  const [message, setMessage] = useState("");
  const [checked, setChecked] = useState(false);
  const [forgotPassword, setForgotPassword] = useState(false);
  const [buttonName, setButtonName] = useState("LOGIN");

  const handleSnackbarClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };
  const storeForgotMail = (event) => {
    let email = event.target.value;
    setForgotPasswordMail(email);
  };
  const handleCheckboxChange = (event) => {
    setChecked(event.target.checked);
  };
  const login = () => {
    if (buttonName === "LOGIN") {
      if (values.username !== "" && values.password !== "") {
        verifyAuth(values)
          .then((res) => {
            sessionStorage.setItem("token", res.data.token);
            sessionStorage.setItem("username", res.data.userDetails.username);
            sessionStorage.setItem(
              "authorities",
              JSON.stringify(res.data.userDetails.authorities)
            );
            window.location.reload();
          })
          .catch((error) => {
            console.log(error);
            setSeverity("error");
            // setMessage(error.response.data);
            setOpen(true);
          });
      } else if (
        values.username == "" &&
        values.password == "" &&
        !sessionStorage.getItem("id")
      ) {
        setSeverity("error");
        setMessage("Please enter Username and Password!");
        setOpen(true);
      }
    } else {
      sendEmail();
    }
  };

  const cancel = () => {
    setForgotPassword(false);
    setButtonName("LOGIN");
  };

  const sendEmail = () => {
    let cred = {
      username: values.username,
      email: forgotPasswordMail,
    };
    userForgotPasswordMail(cred)
      .then((res) => {
        props.history.push("/resetPassword");
      })
      .catch((error) => {
        setSeverity("error");
        setMessage("Something went wrong!");
        setOpen(true);
      });
  };

  const handleChangeForm = (name) => (event) => {
    setValues({ ...values, [name]: event.target.value });
  };

  const handleForgotPassword = () => {
    setForgotPassword(true);
    setButtonName("SEND EMAIL");
  };

  return (
    <div className="loginScreen">
      <Grid container>
        <Grid md={12} className="ps-2">
          <img
            src="/infiniteLogo.png"
            alt=""
            className="float-start"
            style={{ height: "40px" }}
          />
        </Grid>
      </Grid>
      <div></div>
      <div className="d-flex mt-1 mb-1">
        <h4 className="text-dark mb-0 ms-2 fw-600">
          Intelligent Testing Framework
        </h4>
      </div>
      <Card
        component="li"
        className="mt-4"
        orientation="horizontal"
        sx={{
          // minWidth: 300,
          flexGrow: 1,
          flexDirection: "column",
          justifyContent: "center",
        }}
      >
        <CardContent>
          <Grid
            container
            className="d-flex justify-content-center"
            sx={{ flexGrow: 1 }}
          >
            <div
              className="border p-4 rounded"
              style={{ background: "rgba(87, 108, 135, 0.5)" }}
            >
              <Grid container sx={{ flexGrow: 1 }}>
                <Grid md={5}></Grid>
                <Grid md={4}>
                  <Avatar
                    style={{
                      backgroundColor: "#0d0d0d",
                      width: "70px",
                      height: "70px",
                    }}
                    src="/broken-image.jpg"
                  />
                </Grid>
                <Grid md={3}>
                  <img
                    src="/images/infiniteWhiteLogo.png"
                    alt=""
                    className="float-end"
                    style={{ height: "40px" }}
                  />
                </Grid>
              </Grid>
              <Box
                sx={{
                  width: 400,
                  backgroundColor: "#fff",
                  marginTop: "-20px",
                }}
                className="p-3 rounded"
              >
                {forgotPassword && (
                  <h4 className="mb-4 pointer">Forgot Password ? </h4>
                )}
                <Box className="p-2 rounded">
                  <h4 className="text-center">Login Here</h4>
                  <div className="position-relative mb-3">
                    <span
                      className="position-absolute py-1"
                      style={{
                        left: 5,
                        top: 7,
                        width: "40px",
                        height: "40px",
                        // backgroundColor: "#0c0202",
                        borderRadius: "50%",
                      }}
                    >
                      <PersonIcon style={{ color: "#0d0d0d" }} />
                    </span>
                    <input
                      type="text"
                      className="form-control rounded px-5"
                      style={{ height: "50px" }}
                      placeholder="Username"
                      onChange={handleChangeForm("username")}
                    />
                  </div>
                  {!forgotPassword && (
                    <div className="position-relative mb-3">
                      <span
                        className="position-absolute py-1"
                        style={{
                          left: 5,
                          top: 7,
                          width: "40px",
                          height: "40px",
                          // backgroundColor: "#0c0202",
                          borderRadius: "50%",
                        }}
                      >
                        <LockIcon style={{ color: "#0d0d0d" }} />
                      </span>
                      <input
                        type="password"
                        className="form-control rounded px-5"
                        style={{ height: "50px" }}
                        placeholder="Password"
                        onChange={handleChangeForm("password")}
                      />
                    </div>
                  )}
                  {forgotPassword && (
                    <div className="position-relative mb-3">
                      <span
                        className="position-absolute py-1"
                        style={{
                          left: 5,
                          top: 7,
                          width: "40px",
                          height: "40px",
                          backgroundColor: "#0c0202",
                          borderRadius: "50%",
                        }}
                      >
                        <MailIcon style={{ color: "#fff" }} />
                      </span>
                      <input
                        type="text"
                        className="form-control rounded-pill px-5"
                        style={{ height: "50px" }}
                        placeholder="Mail"
                        onChange={storeForgotMail}
                      />
                    </div>
                  )}
                  {!forgotPassword && (
                    <div className="d-flex justify-content-between">
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={checked}
                            onChange={handleCheckboxChange}
                          />
                        }
                        label="Remember me"
                      />
                      <p
                        className="mt-3 pointer"
                        onClick={handleForgotPassword}
                      >
                        Forgot Password?
                      </p>
                    </div>
                  )}
                  <div className="d-flex justify-content-center">
                    <Button
                      variant="contained"
                      style={{ backgroundColor: "#0c0202" }}
                      type="submit"
                      className="loginBtn rounded-pill me-1"
                      onClick={login}
                    >
                      {buttonName}
                    </Button>
                    {forgotPassword && (
                      <Button
                        variant="contained"
                        style={{ backgroundColor: "#0c0202" }}
                        type="submit"
                        className="rounded-pill"
                        onClick={cancel}
                      >
                        CANCEL
                      </Button>
                    )}
                    <Snackbar
                      open={open}
                      autoHideDuration={3000}
                      onClose={handleSnackbarClose}
                      anchorOrigin={{ vertical: "top", horizontal: "center" }}
                      className="snackbar-root"
                    >
                      <MuiAlert
                        elevation={6}
                        variant="filled"
                        onClose={handleSnackbarClose}
                        severity={severity}
                      >
                        {message}
                      </MuiAlert>
                    </Snackbar>
                  </div>
                </Box>
              </Box>
              {!forgotPassword && (
                <div className="d-flex justify-content-center my-2">
                  <p className="text-white">
                    {/* Don't have account? ,{" "}
                    <Link to="/signup" style={{ color: "yellow" }}>
                      Sign Up
                    </Link> */}
                  </p>
                </div>
              )}
            </div>
          </Grid>
        </CardContent>
      </Card>
    </div>
  );
}
