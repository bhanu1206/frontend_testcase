import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import { Home } from "./components/home";
import PersonRoundedIcon from "@mui/icons-material/PersonRounded";
import { IconButton } from "@mui/material";
import AuthProvider from "./helpers/authProvider";
import Routes from "./config/routes";
import { useEffect, useState } from "react";

function App() {
  let [token, setToken] = useState(false);

  useEffect(() => {
    getToken();
  }, []);

  const getToken = () => {
    setToken(sessionStorage.getItem("token") ? true : false);
  };

  return (
    <div className="App">
      {/* {token ? ( */}
        <nav className="navbar navbar-expand-lg navbar-light bg-light justify-content-between">
          <a className="navbar-brand mx-3" href="/#" style={{fontWeight : 600}}>
            <img
              src="https://w7.pngwing.com/pngs/679/736/png-transparent-computer-icons-test-survey-miscellaneous-angle-text-thumbnail.png"
              width="30"
              height="30"
              className="d-inline-block align-top"
              alt=""
            />
            &nbsp; Intelligent Testing Framework
          </a>

          <IconButton className="mx-3">
            <PersonRoundedIcon />
          </IconButton>
        </nav>
      {/* ) : (
        ""
      )} */}
      <AuthProvider>
        <Routes />
      </AuthProvider>
    </div>
  );
}

export default App;
