import axiosConfig from "../config/axiosConfig";

export const verifyRepository = (url) => {
  return axiosConfig.post("verifyRepository", { repo_url: url });
};

export const chooseBranch = (repoUrl, branch) => {
  return axiosConfig.post("selectBranch", {
    repo_url: repoUrl,
    branch: branch,
  });
};

export const generateTestCases = (app) => {
  return axiosConfig.post("generateTestCases", { applicationName: app });
};
